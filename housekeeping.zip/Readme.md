#Its a web application developed with html ,nodejs and backend on MongoDB.

##
1)open cmd 
2)Go to respective directory 
3)Type "npm i"
4)type "node index.js"
5)open on "localhost:5000" on chrome browser.

